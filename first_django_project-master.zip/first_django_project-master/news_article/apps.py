from django.apps import AppConfig


class NewsArticleConfig(AppConfig):
    name = 'news_article'
