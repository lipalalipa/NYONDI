from django.apps import AppConfig


class HappyBirthdayConfig(AppConfig):
    name = 'happy_birthday'
